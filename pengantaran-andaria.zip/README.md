# Pengantaran Andaria

Web app sederhana untuk mencatat pengantaran (supir, plat mobil, rute, tanggal, verifikasi admin) menggunakan **Firebase Firestore**.

## Cara cepat deploy ke GitHub Pages
1. Fork / clone repo, atau upload file `index.html` ini ke repositori publik.
2. Di GitHub → **Settings → Pages** → Source: Branch `main`, folder `/root`.
3. Tunggu 1‑2 menit. Aplikasi online di:  
   `https://<username>.github.io/<repo>/`

Nikmati!
